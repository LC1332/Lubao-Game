python CarDirectionGame_score.py
